﻿namespace SampleAPIProject.Models
{
    using System;

    public class QualificationModel
    {
        public int QId { get; set; }
        public string Qualification1 { get; set; }
        public Nullable<long> EmpId { get; set; }
        public string Percentage { get; set; }
        public string Specialization { get; set; }
        public string YearPassedout { get; set; }
        public string University { get; set; }
        public string State { get; set; }
    }
}
