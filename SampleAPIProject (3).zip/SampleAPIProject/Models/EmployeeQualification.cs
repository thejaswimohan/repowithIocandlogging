﻿namespace SampleAPIProject.Models
{
    public class EmployeeQualification
    {
       public EmployeeModel employee { get; set; }
       public QualificationModel qualification { get; set; }
      
    }
}