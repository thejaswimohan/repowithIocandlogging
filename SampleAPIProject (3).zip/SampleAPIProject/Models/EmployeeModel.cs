﻿namespace SampleAPIProject.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class EmployeeModel : IComparable<EmployeeModel>
    {
        public long id { get; set; }
        [Required(ErrorMessage = "Name is Must")]
        public string name { get; set; }
        [Required(ErrorMessage = "DeptName is Must")]
        public string department { get; set; }
        [Required(ErrorMessage = "Salary is Must")]
        public long salary { get; set; }

        public int CompareTo(EmployeeModel other)
        {
            if (this.salary == other.salary)
            {
                return this.name.CompareTo(other.name);
            }
            return other.salary.CompareTo(this.salary);
        }
    }
}