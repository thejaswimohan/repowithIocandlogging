﻿namespace SampleAPIProject.IOC
{
    using SampleAPIProject.Domain;
    using SampleAPIProject.Logging;
    using System.Web.Http;
    using Unity;
    using Unity.Lifetime;

    public static class Container
    {
        public static void Register(HttpConfiguration config)
        {
            var container = new UnityContainer();
            container.RegisterType<IEmployeeObject, EmployeeObject>(new HierarchicalLifetimeManager());
            container.RegisterType<ILogger, Logger>(new HierarchicalLifetimeManager());

            config.DependencyResolver = new UnityResolver(container);
        }
    }
}