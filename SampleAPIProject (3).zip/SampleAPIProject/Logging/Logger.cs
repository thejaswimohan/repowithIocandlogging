﻿namespace SampleAPIProject.Logging
{
    public class Logger : ILogger
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public void Error(string message)
        {
            logger.Error(message);
        }
        public void Debug(string message)
        {
            logger.Debug(message);
        }
        public void Info(string message)
        {
            logger.Info(message);
        }

    }
}