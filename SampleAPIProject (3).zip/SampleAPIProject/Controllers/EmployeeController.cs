﻿namespace SampleAPIProject.Controllers
{    
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using System.Web.Http.Description;
    using SampleAPIProject.Domain;
    using SampleAPIProject.ExceptionHandling;
    using SampleAPIProject.Logging;

    public class EmployeeController : ApiController
    {
        IEmployeeObject employeeObject;
        ILogger logger; //NLOG Configuration

       public EmployeeController() { }

       //Dependency Injection 
       public EmployeeController(IEmployeeObject _employeeObject, ILogger _logger)
        {
           employeeObject = _employeeObject;
           logger = _logger;
        }

         [Route("api/GetEmployees")]
        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            try
            {
                return await employeeObject.GetEmployees();
            }//Custom Exception Handling
            catch (EmployeeException employeeException)
            {
                throw employeeException;
            }
        }

        [Route("api/GetEmployeesSortBySalary")]
        public List<Employee> GetEmployeesSortBySalary()
        {
            try
            {
                logger.Debug("Get Employees Sort By Salary API Hit....");
                return employeeObject.GetEmployeesSortBySalary();
            }
            catch (EmployeeException employeeException)
            {
                throw employeeException;
            }
        }

        [Route("api/GetEmployee")]
        [ResponseType(typeof(Employee))]
        public async Task<HttpResponseMessage> GetEmployee(int id)
        {
            try
            {
                Employee employee = await Task.Run(() => employeeObject.GetEmployee(id));
                if (employee == null){
                    return Request.CreateResponse(HttpStatusCode.NotFound); }

                return Request.CreateResponse(HttpStatusCode.OK, employee);
            }
            catch (EmployeeException employeeException)
            {
                throw employeeException;
            }
        }

        [ResponseType(typeof(Employee))]
        [Route("api/PostEmployee", Name = "PostEmployee")]
        public IHttpActionResult PostEmployee(Employee employee)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    employeeObject.PostEmployee(employee);
                }
                else
                { throw new EmployeeException("Bad request"); }
            }
            catch (EmployeeException employeeException)
            {
                throw employeeException;
            }

            return Ok();
        }

        [Route("api/PutEmployee/{id}")]
        public IHttpActionResult PutEmployee(long id, [FromBody]Employee employee)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    employeeObject.PutEmployee(id, employee);
                }
            }
            catch (EmployeeException employeeException)
            {
                throw employeeException;
            }
            return StatusCode(HttpStatusCode.NoContent);
        }        

        [Route("api/DeleteEmployee")]
        [ResponseType(typeof(Employee))]
        public IHttpActionResult DeleteEmployee(int id)
        {
            Employee employee = employeeObject.GetEmployee(id);
            if (employee == null)
            {
                throw new EmployeeException("Employee record not Found");
            }
            employeeObject.DeleteEmployee(id);

            return Ok(employee);
        }

        protected override void Dispose(bool disposing)
        {
            employeeObject.UOWDispose(disposing);
            base.Dispose(disposing);
        }

    }
}