﻿namespace SampleAPIProject.ExceptionHandling
{
    using System;

    public class EmployeeException : Exception
    {
        public EmployeeException(string message)
           : base(message)
        {

        }
    }
}