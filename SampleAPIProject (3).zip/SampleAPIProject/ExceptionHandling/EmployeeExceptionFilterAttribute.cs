﻿namespace SampleAPIProject.ExceptionHandling
{
    using System;
    using SampleAPIProject.Logging;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http.Filters;

    public class EmployeeExceptionFilterAttribute : ExceptionFilterAttribute, IExceptionFilter
    {
        ILogger logger;
        public EmployeeExceptionFilterAttribute(ILogger _logger)
        {
            logger = _logger;
        }
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            if (actionExecutedContext.Exception is EmployeeException)
            {
                var exceptionMessage = string.Empty;
                if (actionExecutedContext.Exception.InnerException == null)
                {
                    logger.Error(string.Format("Action Method {0} executing at {1}", actionExecutedContext.ActionContext.ActionDescriptor.ActionName, DateTime.Now.ToShortDateString()));
                    exceptionMessage = actionExecutedContext.Exception.Message;
                }
                else
                {
                    logger.Error(string.Format("Action Method {0} executing at {1}", actionExecutedContext.Exception.InnerException.Message.ToString(), DateTime.Now.ToShortDateString()));
                    exceptionMessage = actionExecutedContext.Exception.InnerException.Message;
                }

                HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(exceptionMessage),
                    ReasonPhrase = exceptionMessage
                };

                actionExecutedContext.Response = response;

                logger.Error(string.Format("Error Occured in {0}", actionExecutedContext.Response));
            }
        }
    }
}