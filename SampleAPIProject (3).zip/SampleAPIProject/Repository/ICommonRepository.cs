﻿namespace SampleAPIProject.Repository
{
    using System.Collections.Generic;

    interface ICommonRepository<T> where T : class
    {
        IEnumerable<T> GetAll();
        T GetById(int id);
        void Add(T entity);
        void Update(T entity);
        void Delete(T entity);
        void Delete(int id);
    }
}
