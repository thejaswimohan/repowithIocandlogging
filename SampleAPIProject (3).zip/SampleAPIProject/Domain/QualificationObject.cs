﻿namespace SampleAPIProject.Domain
{
    using SampleAPIProject.Models;
    using SampleAPIProject.Repository;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class QualificationObject : IQualificationObject
    {
        private UnitOfWork unitOfWork = new UnitOfWork();

        public async Task<IEnumerable<Qualification>> GetQualifications()
        {
            var employee = await Task.Run(() => unitOfWork.Qualification_Repository.GetAll());
            return employee;
        }

        public IList<Qualification> getQualificationByEmpId(int id)
        {
            IList<Qualification> qualification = null;

            using (var ctx = new EmployeeEntities())
            {
                qualification = (from s in ctx.Qualifications.AsParallel() where s.EmpId == id select new Qualification() { Qualification1 = s.Qualification1, Percentage = s.Percentage, Specialization = s.Specialization }).ToList();
            }
            return qualification;
        }

        //Linq Left Outer Join
        public List<EmployeeQualification> GetEmployeeQualificationDetails()
        {
            using (var ctx = new EmployeeEntities())
            {
                var employeeDetails = (from a in ctx.Employees
                                       join b in ctx.Qualifications on a.ID equals b.EmpId into T
                                       from p in T.DefaultIfEmpty()
                                       select new EmployeeQualification() {
                                           employee = new EmployeeModel
                                           {
                                               id =a.ID,
                                               name =a.Name,
                                               department =a.Department,
                                               salary =a.Salary
                                           } ,
                                           qualification =new QualificationModel
                                           {
                                               QId = p.QId,
                                               EmpId = p.EmpId,
                                               Qualification1 = p.Qualification1,
                                               Specialization = p.Specialization,
                                               Percentage = p.Percentage,
                                               YearPassedout = p.YearPassedout,
                                               University = p.University,
                                               State = p.State
                                           }}).ToList();

                return employeeDetails;
            }
        }
    }

   
}
