﻿namespace SampleAPIProject.Domain
{
    using SampleAPIProject.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;

   public interface IEmployeeObject
    {
        Task<IEnumerable<Employee>> GetEmployees();
        List<Employee> GetEmployeesSortBySalary();
        Employee GetEmployee(int id);
        void PutEmployee(long id, Employee employee);
        void PostEmployee(Employee employee);
        Employee DeleteEmployee(int id);
        void UOWDispose(bool disposing);
    }
}
