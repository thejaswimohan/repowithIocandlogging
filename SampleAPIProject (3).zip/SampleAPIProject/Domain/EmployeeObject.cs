﻿namespace SampleAPIProject.Domain
{
    using SampleAPIProject.Repository;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class EmployeeObject : IEmployeeObject
    {
        private UnitOfWork unitOfWork = new UnitOfWork();
       
        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            var employee = await Task.Run(() => unitOfWork.employee_Repository.GetAll());
            return employee;
        }

        public List<Employee> GetEmployeesSortBySalary()
        {
            var employee = unitOfWork.employee_Repository.GetAll().ToList();
            employee.Sort();
            return employee;
        }

        public Employee GetEmployee(int id)
        {
            Employee employee = unitOfWork.employee_Repository.GetById(id);           
            return employee;
        }       

        public void PutEmployee(long id, Employee employee)
        {
            unitOfWork.employee_Repository.Update(employee);
            unitOfWork.Save();
        }
        
        public void PostEmployee(Employee employee)
        {
            unitOfWork.employee_Repository.Add(employee);
            unitOfWork.Save();
        }
        
        public Employee DeleteEmployee(int id)
        {
            Employee employee = unitOfWork.employee_Repository.GetById(id);
            if (employee != null)
            {
                unitOfWork.employee_Repository.Delete(employee);
                unitOfWork.Save();
            }
            return employee;
        }    

        public void UOWDispose(bool disposing)
        {
            if (disposing)
            {
                unitOfWork.Dispose();
            }
        }

    }
}