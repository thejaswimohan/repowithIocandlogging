﻿namespace SampleAPIProject.Domain
{
    using System.Collections.Generic;

    interface IQualificationObject
    {
        IList<Qualification> getQualificationByEmpId(int id);
    }
}
