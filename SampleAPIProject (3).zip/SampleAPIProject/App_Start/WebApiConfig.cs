﻿namespace SampleAPIProject
{
    using SampleAPIProject.ExceptionHandling;
    using SampleAPIProject.IOC;
    using SampleAPIProject.Logging;
    using System.Web.Http;

    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API routes
            config.MapHttpAttributeRoutes();
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //Exception Handling in filters
            config.Filters.Add(new EmployeeExceptionFilterAttribute(new Logger()));

            //dependency Resolver
            Container.Register(config);
        }
    }
}
