﻿namespace SampleNunit.Test
{
    using NUnit.Framework;
    using SampleAPIProject;
    using SampleAPIProject.Domain;

    [TestFixture]
    public class EmployeeObjectTest
    {
        IEmployeeObject controller = null;
        Employee employee;

        [SetUp]
        public void RunsBeforeEachtest()
        {
            controller = new EmployeeObject();
            employee = new Employee();
        }

        [Test]        
        public void Should_Return_True_When_Response_Of_GetEmployees_Has_Records()
        {           
            GivenTheRequestToGetTheListOfEmployeesAndReturnsTrue();
        }

        [Test]
        public void Should_Return_True_When_Response_Of_GetEmployee_ById_Has_Records()
        {
            GivenTheRequestWithIdToGetAnEmployeeAndReturnsTrue();
        }

        [Test]
        public void Should_Return_False_When_Response_Of_GetEmployee_ById_Has_NoRecords()
        {
            GivenTheRequestWithIdToGetAnEmployeeAndReturnsFalse();
        }

        [Test]
        public void Should_Return_True_When_Response_Of_GetEmployee_Sort_BySalary_Has_Records()
        {
            GivenTheRequestToGetEmployeesSortBySalaryAndReturnsTrue();
        }

        [Test]
        public void Should_Return_True_When_Inserted_A_New_Record()
        {
            GivenTheRequestToInsertAnEmployeesToTheDBAndReturnsTrue();
        }

        [Test]
        public void Should_Return_True_When_Update_An_Existing_Record()
        {
            GivenTheRequestToInsertAnEmployeesToTheDBAndReturnsTrue();
        }

        private void GivenTheRequestToInsertAnEmployeesToTheDBAndReturnsTrue()
        {
            employee = new Employee() { Name = "ABC", Department = "Java", Salary = 12321 };
            controller.PostEmployee(employee);
        }

        private void GivenTheRequestToUpdateAnEmployeesInTheDBAndReturnsTrue()
        {
            employee = new Employee() { Name = "Roy sharma", Department = "IT", Salary = 52321 };
            controller.PutEmployee(140003, employee);
        }

        private void GivenTheRequestToGetEmployeesSortBySalaryAndReturnsTrue()
        {
            var result = controller.GetEmployeesSortBySalary();
            Assert.IsTrue(result != null);
        }
        
        private void GivenTheRequestToGetTheListOfEmployeesAndReturnsTrue()
        {
            var result = controller.GetEmployees();
            Assert.IsTrue(result != null);
        }        

        private void GivenTheRequestWithIdToGetAnEmployeeAndReturnsTrue()
        {            
            employee = controller.GetEmployee(40004);            
            Assert.IsTrue("Kavin" == employee.Name);
        }

        private void GivenTheRequestWithIdToGetAnEmployeeAndReturnsFalse()
        {
            employee = controller.GetEmployee(10004);
            Assert.IsFalse(employee != null);
        }
    }
}
